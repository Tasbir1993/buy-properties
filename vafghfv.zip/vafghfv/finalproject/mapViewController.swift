//
//  mapViewController.swift
//  finalproject
//
//  Created by Tasbir Singh on 2017-11-01.
//  Copyright © 2017 Tasbir Singh. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Foundation

class mapViewController: UIViewController,CLLocationManagerDelegate, MKMapViewDelegate, UITextFieldDelegate {

    @IBOutlet weak var map: MKMapView!
    var mapManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        map.isZoomEnabled = true
        
        // Do any additional setup after loading the view, typically from a nib.
        
        // Do application set-up
        
        mapManager.delegate = self                            // ViewController is the "owner" of the map.
        mapManager.desiredAccuracy = kCLLocationAccuracyBest  // Define the best location possible to be used in app.
        mapManager.requestWhenInUseAuthorization()            // The feature will not run in background
        mapManager.startUpdatingLocation()                    // Continuously geo-position update

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // The array locations stores all the user's positions, and the position 0 is the most recent one
        let location = locations[0]
        
        // Here we define the map's zoom. The value 0.01 is a pattern
        let zoom:MKCoordinateSpan = MKCoordinateSpanMake(0.7, 0.7)
        
        // Store latitude and longitude received from smartphone
        let myLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude)
        let location1:CLLocationCoordinate2D = CLLocationCoordinate2DMake(43.595310, -79.765072)
        let location2:CLLocationCoordinate2D = CLLocationCoordinate2DMake(43.595310,-79.640579)
        
        // Based on myLocation and zoom define the region to be shown on the screen
        let region:MKCoordinateRegion = MKCoordinateRegionMake(myLocation, zoom)
        // let region1:MKCoordinateRegion = MKCoordinateRegionMake(location1, zoom)
        //let region2:MKCoordinateRegion = MKCoordinateRegionMake(location2,zoom)
        
        // Setting the map itself based previous set-up
        map.setRegion(region, animated: true)
        // map.setRegion(region1, animated: true)
        // map.setRegion(region2, animated: true)
        
        // Showing the blue dot in a map
        map.showsUserLocation = true
        
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        
        let annotation1 = MKPointAnnotation()
        annotation1.coordinate = location1
        annotation1.title = "BRAMPTON"
        annotation1.subtitle = "properties in Brampton"
        
        let annotation2 = MKPointAnnotation()
        annotation2.coordinate = location2
        annotation2.title = "mississauga"
        annotation2.subtitle = "properties in missisauga"
        map.addAnnotation(annotation1)
        map.addAnnotation(annotation2)
        
        
        
    }
    
}



    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


