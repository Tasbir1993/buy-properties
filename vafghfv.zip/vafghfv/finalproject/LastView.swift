//
//  LastView.swift
//  finalproject
//
//  Created by Tasbir Singh on 2017-11-07.
//  Copyright © 2017 Tasbir Singh. All rights reserved.
//

import UIKit

class LastView: UIViewController
{

    @IBAction func btn_Home(_ sender: UIButton)
    {
        self.navigationController?.popToRootViewController(animated: true)
    }
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
