//
//  PayViewController.swift
//  finalproject
//
//  Created by Tasbir Singh on 2017-11-03.
//  Copyright © 2017 Tasbir Singh. All rights reserved.
//

import UIKit

class PayViewController: UIViewController {
    
    @IBOutlet weak var payfield: UITextField!
     var amountToDisplay = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        payfield.text = amountToDisplay

        // Do any additional setup after loading the view.
    }

    @IBAction func btn_Go(_ sender: UIButton)
    {
        performSegue(withIdentifier: "lastview", sender: self)
    }
    
    @IBAction func Back(_ sender: UIButton)
    {
        dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "lastview")
        {
            let lastview = segue.destination as! LastView
        }
    }

    

}
