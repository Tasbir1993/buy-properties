//
//  mipayViewController.swift
//  finalproject
//
//  Created by Tasbir Singh on 2017-11-06.
//  Copyright © 2017 Tasbir Singh. All rights reserved.
//

import UIKit

class mipayViewController: UIViewController {
    
    @IBAction func btn_Go(_ sender: UIButton)
    {
        performSegue(withIdentifier: "lastview", sender: self)

    }
    
    @IBOutlet weak var payfield1: UITextField!
    var displayamount = ""
    

    override func viewDidLoad() {
        super.viewDidLoad()
        payfield1.text = displayamount

        // Do any additional setup after loading the view.
    }

   
    @IBAction func Back(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "lastview")
        {
            let lastview = segue.destination as! LastView
        }
    }
}
