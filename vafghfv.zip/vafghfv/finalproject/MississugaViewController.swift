//
//  MississugaViewController.swift
//  finalproject
//
//  Created by Tasbir Singh on 2017-11-03.
//  Copyright © 2017 Tasbir Singh. All rights reserved.
//

import UIKit

class MississugaViewController: UIViewController, UITextFieldDelegate{
    @IBOutlet weak var butn1: UIButton!
    @IBOutlet weak var butn2: UIButton!
    @IBOutlet weak var butn3: UIButton!
    @IBOutlet weak var txtrslt: UITextField!
    var status1:Int=0
    var status2:Int=0
    var status3:Int=0
    
    var BoxOn = UIImage(named: "chkboximg")
    var BoxOff = UIImage(named: "unchkboximg")
    
    var isBoxClicked: Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        isBoxClicked = false
       
        
        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    @IBAction func b1(_ sender: UIButton){
        if isBoxClicked == true{
            isBoxClicked = false
            status1=0
        }else{
            isBoxClicked = true
            status1=1
        }
        
        if isBoxClicked == true{
            butn1.setImage(BoxOn, for: UIControlState.normal)
            
        }
        else{
            butn1.setImage(BoxOff, for: UIControlState.normal)
        }
        
    }
    
    @IBAction func b2(_ sender: UIButton) {
        if isBoxClicked == true{
            status2=0
            isBoxClicked = false
            
        }else{
            status2=1
            isBoxClicked = true
        }
        
        if isBoxClicked == true{
            butn2.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            butn2.setImage(BoxOff, for: UIControlState.normal)
        }
        
        
        
    }

    @IBAction func b3(_ sender: UIButton) {
        
        if isBoxClicked == true{
            isBoxClicked = false
            status3=0
        }else{
            isBoxClicked = true
            
            status3=1
        }
        
        if isBoxClicked == true{
            butn3.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            butn3.setImage(BoxOff, for: UIControlState.normal)
        }
        
    }
    
  
    @IBAction func buy1(_ sender: UIButton) {
    
    var totalamount:Int=0
        if(status1==1){
            totalamount=totalamount+10000
            
        }
        
        if(status2==1){
            totalamount=totalamount+7000
            
        }
        if(status3==1){
            totalamount=totalamount+5500
            
        }
        print(totalamount)
        txtrslt.text = "\(totalamount)"
        
    }
    
    @IBAction func proceed(_ sender: UIButton) {
        performSegue(withIdentifier: "payview1", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if(segue.identifier == "payview1")
        {
            let destVC = segue.destination as!
            mipayViewController
            destVC.displayamount = txtrslt.text!
            
        }
    }
    
    
}

   
    

