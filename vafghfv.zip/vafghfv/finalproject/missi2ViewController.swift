//
//  missi2ViewController.swift
//  finalproject
//
//  Created by Tasbir Singh on 2017-11-03.
//  Copyright © 2017 Tasbir Singh. All rights reserved.
//

import UIKit

class missi2ViewController: UIViewController {

    @IBOutlet weak var finalamount: UITextField!
    var amntToDisplay = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        finalamount.text = amntToDisplay

        // Do any additional setup after loading the view.
    }

    @IBAction func backpress(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    

}
