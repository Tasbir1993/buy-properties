//
//  bramptonViewController.swift
//  finalproject
//
//  Created by Tasbir Singh on 2017-11-03.
//  Copyright © 2017 Tasbir Singh. All rights reserved.
//

import UIKit

class bramptonViewController: UIViewController,UITextFieldDelegate {
    
    
    @IBOutlet weak var b1: UIButton!
    @IBOutlet weak var b2: UIButton!
    @IBOutlet weak var b3: UIButton!    
    @IBOutlet weak var result: UITextField!
    var st1:Int=0
    var st2:Int=0
    var st3:Int=0
    var BoxOn = UIImage(named: "chkboximg")
    var BoxOff = UIImage(named: "unchkboximg")
    
    var isBoxClicked: Bool!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        isBoxClicked = false
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func box1(_ sender: UIButton) {
        if isBoxClicked == true{
            isBoxClicked = false
            st1=0
        }else{
            isBoxClicked = true
            st1=1
        }
        
        if isBoxClicked == true{
            b1.setImage(BoxOn, for: UIControlState.normal)
            
        }
        else{
            b1.setImage(BoxOff, for: UIControlState.normal)
        }
    }
    
 
    @IBAction func box2(_ sender: UIButton)
    {
        
        if isBoxClicked == true{
            st2=0
            isBoxClicked = false
            
        }else{
            st2=1
            isBoxClicked = true
        }
        
        if isBoxClicked == true{
            b2.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            b2.setImage(BoxOff, for: UIControlState.normal)
        }
        
    }
    
    
    @IBAction func box3(_ sender: UIButton) {
    
    if isBoxClicked == true{
            isBoxClicked = false
            st3=0
        }else{
            isBoxClicked = true
            
            st3=1
        }
        
        if isBoxClicked == true{
            b3.setImage(BoxOn, for: UIControlState.normal)
        }
        else{
            b3.setImage(BoxOff, for: UIControlState.normal)
        }
        
}
    
    @IBAction func Buy(_ sender: UIButton) {
        
        var amount:Int=0
        if(st1==1){
           amount=amount+5000
            
        }
        
        if(st2==1){
        amount=amount+5500
            
        }
        if(st3==1){
           amount=amount+7600
            
        }
        print(amount)
        result.text = "\(amount)"
        }
    
    @IBAction func Pay(_ sender: UIButton) {
       performSegue(withIdentifier: "payview", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if(segue.identifier == "payview")
        {
        
        let destVC = segue.destination as! PayViewController
        destVC.amountToDisplay = result.text!
        }
        
    }
    
    
}
